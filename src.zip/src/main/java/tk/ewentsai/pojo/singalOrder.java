package tk.ewentsai.pojo;

import lombok.Data;

@Data
public class singalOrder {
    private int id;
    private int orderId;
    private int bookId;
}
