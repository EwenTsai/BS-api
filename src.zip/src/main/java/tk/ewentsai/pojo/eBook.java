package tk.ewentsai.pojo;

import lombok.Data;

@Data
public class eBook {
    private int id;
    private String bookname;
    private String downloadLink;
}
