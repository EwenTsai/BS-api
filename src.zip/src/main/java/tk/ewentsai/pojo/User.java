package tk.ewentsai.pojo;

import lombok.Data;
@Data
public class User {
	private int uid;
	private String uname;
	private String pwd;
	private String age;
	private String birthday;
	private String imageAdress;
}
