package tk.ewentsai.BTS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
